// User & Auth Types
export type UserRole = 'citizen' | 'officer' | 'field_worker' | 'department_head' | 'admin'

export interface User {
  id: string
  name: string
  phone: string
  email?: string
  role: UserRole
  ward?: string
  zone?: string
  department?: string
  avatar?: string
  isVerified: boolean
  aadhaarLinked: boolean
  createdAt: string
}

// Complaint Types
export type ComplaintStatus = 
  | 'pending'
  | 'assigned'
  | 'in_progress'
  | 'work_completed'
  | 'resolved'
  | 'rejected'
  | 'closed'
  | 'reopened'

export type ComplaintPriority = 'low' | 'medium' | 'high' | 'critical'

export interface Category {
  id: string
  name: string
  icon: string
  subcategories: SubCategory[]
}

export interface SubCategory {
  id: string
  name: string
  slaHours: number
}

export interface Complaint {
  id: string
  displayId: string // e.g., "CR-2026-00142"
  title?: string
  description: string
  category: Category
  subcategory: SubCategory
  status: ComplaintStatus
  priority: ComplaintPriority
  location: {
    lat: number
    lng: number
    address: string
    landmark?: string
    ward: string
    zone: string
  }
  images: string[]
  citizenId: string
  citizenName?: string
  assignedOfficerId?: string
  assignedOfficerName?: string
  departmentId: string
  departmentName: string
  upvotes: number
  hasUpvoted?: boolean
  slaDeadline: string
  slaBreached: boolean
  slaRemainingHours?: number
  rating?: number
  ratingComment?: string
  timeline: TimelineEvent[]
  comments: Comment[]
  createdAt: string
  updatedAt: string
  resolvedAt?: string
}

export interface TimelineEvent {
  id: string
  status: ComplaintStatus
  message: string
  by: string
  byRole: UserRole
  timestamp: string
}

export interface Comment {
  id: string
  message: string
  by: string
  byRole: UserRole
  isInternal: boolean
  timestamp: string
}

// Ward & Department Types
export interface Ward {
  id: string
  number: number
  name: string
  zone: string
  corporatorName: string
  officersCount: number
  boundary?: Record<string, unknown>
}

export interface Department {
  id: string
  name: string
  nameHindi?: string
  headOfficerId?: string
  headOfficerName?: string
  contact: string
  defaultSlaHours: number
  activeComplaints: number
}

// Notification Types
export type NotificationType = 
  | 'status_update'
  | 'comment'
  | 'assignment'
  | 'sla_warning'
  | 'sla_breach'
  | 'system'

export interface Notification {
  id: string
  type: NotificationType
  title: string
  message: string
  complaintId?: string
  isRead: boolean
  timestamp: string
}

// Analytics Types
export interface DashboardStats {
  total: number
  pending: number
  inProgress: number
  resolved: number
  slaBreached: number
  avgResolutionDays: number
  satisfactionRating: number
}

export interface ChartData {
  name: string
  value: number
  fill?: string
}

export interface TrendData {
  date: string
  complaints: number
  resolved: number
}

// Announcement Types
export interface Announcement {
  id: string
  title: string
  content: string
  target: 'all' | 'ward' | 'zone'
  targetId?: string
  isPublished: boolean
  publishedAt?: string
  createdAt: string
}

// API Types
export interface PaginatedResponse<T> {
  data: T[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
    hasNext: boolean
    hasPrev: boolean
  }
}

export interface ApiError {
  message: string
  code: string
  details?: Record<string, string[]>
}
